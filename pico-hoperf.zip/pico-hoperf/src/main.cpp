#include <pico/stdlib.h>
#include <RadioLib.h>
#include "RadioLibPicoHal.h"

// define pins to be used
#define SPI_PORT spi0
#define SPI_MISO 16
#define SPI_MOSI 19
#define SPI_SCK 18

#define RFM_NSS 17
#define RFM_RST 20
#define RFM_DIO0 27
#define RFM_DIO1 29

// create a new instance of the HAL class
PicoHal* hal = new PicoHal(SPI_PORT, SPI_MISO, SPI_MOSI, SPI_SCK);

// SX1278 is RFM98
SX1278 radio = new Module(hal, RFM_NSS, RFM_DIO0, RFM_RST, RFM_DIO1);

int main() {

  stdio_init_all();

  sleep_ms(3000);

  // initialize just like with Arduino
  printf("[SX1278] Initializing ... ");
  int state = radio.begin();
  if (state != RADIOLIB_ERR_NONE) {
    while (true) {
      if (state == RADIOLIB_ERR_NONE) { break; }
      printf("failed, code %d\n", state);
      sleep_ms(1000);
      state = radio.begin();
    }
  }
  printf("success!\n");

  // loop forever
  for(;;) {
    // send a packet
    printf("[SX1276] Transmitting packet ... ");
    state = radio.transmit("Hello World!");
    if(state == RADIOLIB_ERR_NONE) {
      // the packet was successfully transmitted
      printf("success!\n");

      // wait for a second before transmitting again
      hal->delay(1000);

    } else {
      printf("failed, code %d\n", state);

    }

  }

  return(0);
}